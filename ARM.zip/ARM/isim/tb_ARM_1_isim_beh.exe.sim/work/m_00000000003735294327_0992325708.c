/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/ARM/mux2.v";



static void Cont_8_0(char *t0)
{
    char t3[8];
    char t4[8];
    char t6[8];
    char t25[8];
    char t26[8];
    char t29[8];
    char t59[8];
    char t60[8];
    char t62[8];
    char *t1;
    char *t2;
    char *t5;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    char *t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    char *t20;
    char *t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    char *t27;
    char *t28;
    char *t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    char *t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    char *t43;
    char *t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    char *t48;
    char *t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    char *t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    char *t61;
    char *t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    char *t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    char *t76;
    char *t77;
    unsigned int t78;
    unsigned int t79;
    unsigned int t80;
    char *t81;
    char *t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    unsigned int t86;
    char *t87;
    char *t88;
    char *t89;
    char *t90;
    char *t91;
    char *t92;

LAB0:    t1 = (t0 + 2848U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(8, ng0);
    t2 = (t0 + 1048U);
    t5 = *((char **)t2);
    memset(t6, 0, 8);
    t2 = (t6 + 4);
    t7 = (t5 + 4);
    t8 = *((unsigned int *)t5);
    t9 = (t8 >> 1);
    t10 = (t9 & 1);
    *((unsigned int *)t6) = t10;
    t11 = *((unsigned int *)t7);
    t12 = (t11 >> 1);
    t13 = (t12 & 1);
    *((unsigned int *)t2) = t13;
    memset(t4, 0, 8);
    t14 = (t6 + 4);
    t15 = *((unsigned int *)t14);
    t16 = (~(t15));
    t17 = *((unsigned int *)t6);
    t18 = (t17 & t16);
    t19 = (t18 & 1U);
    if (t19 != 0)
        goto LAB4;

LAB5:    if (*((unsigned int *)t14) != 0)
        goto LAB6;

LAB7:    t21 = (t4 + 4);
    t22 = *((unsigned int *)t4);
    t23 = *((unsigned int *)t21);
    t24 = (t22 || t23);
    if (t24 > 0)
        goto LAB8;

LAB9:    t55 = *((unsigned int *)t4);
    t56 = (~(t55));
    t57 = *((unsigned int *)t21);
    t58 = (t56 || t57);
    if (t58 > 0)
        goto LAB10;

LAB11:    if (*((unsigned int *)t21) > 0)
        goto LAB12;

LAB13:    if (*((unsigned int *)t4) > 0)
        goto LAB14;

LAB15:    memcpy(t3, t59, 8);

LAB16:    t81 = (t0 + 3248);
    t88 = (t81 + 56U);
    t89 = *((char **)t88);
    t90 = (t89 + 56U);
    t91 = *((char **)t90);
    memcpy(t91, t3, 8);
    xsi_driver_vfirst_trans(t81, 0, 31);
    t92 = (t0 + 3168);
    *((int *)t92) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t4) = 1;
    goto LAB7;

LAB6:    t20 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t20) = 1;
    goto LAB7;

LAB8:    t27 = (t0 + 1048U);
    t28 = *((char **)t27);
    memset(t29, 0, 8);
    t27 = (t29 + 4);
    t30 = (t28 + 4);
    t31 = *((unsigned int *)t28);
    t32 = (t31 >> 0);
    t33 = (t32 & 1);
    *((unsigned int *)t29) = t33;
    t34 = *((unsigned int *)t30);
    t35 = (t34 >> 0);
    t36 = (t35 & 1);
    *((unsigned int *)t27) = t36;
    memset(t26, 0, 8);
    t37 = (t29 + 4);
    t38 = *((unsigned int *)t37);
    t39 = (~(t38));
    t40 = *((unsigned int *)t29);
    t41 = (t40 & t39);
    t42 = (t41 & 1U);
    if (t42 != 0)
        goto LAB17;

LAB18:    if (*((unsigned int *)t37) != 0)
        goto LAB19;

LAB20:    t44 = (t26 + 4);
    t45 = *((unsigned int *)t26);
    t46 = *((unsigned int *)t44);
    t47 = (t45 || t46);
    if (t47 > 0)
        goto LAB21;

LAB22:    t50 = *((unsigned int *)t26);
    t51 = (~(t50));
    t52 = *((unsigned int *)t44);
    t53 = (t51 || t52);
    if (t53 > 0)
        goto LAB23;

LAB24:    if (*((unsigned int *)t44) > 0)
        goto LAB25;

LAB26:    if (*((unsigned int *)t26) > 0)
        goto LAB27;

LAB28:    memcpy(t25, t54, 8);

LAB29:    goto LAB9;

LAB10:    t48 = (t0 + 1048U);
    t61 = *((char **)t48);
    memset(t62, 0, 8);
    t48 = (t62 + 4);
    t63 = (t61 + 4);
    t64 = *((unsigned int *)t61);
    t65 = (t64 >> 0);
    t66 = (t65 & 1);
    *((unsigned int *)t62) = t66;
    t67 = *((unsigned int *)t63);
    t68 = (t67 >> 0);
    t69 = (t68 & 1);
    *((unsigned int *)t48) = t69;
    memset(t60, 0, 8);
    t70 = (t62 + 4);
    t71 = *((unsigned int *)t70);
    t72 = (~(t71));
    t73 = *((unsigned int *)t62);
    t74 = (t73 & t72);
    t75 = (t74 & 1U);
    if (t75 != 0)
        goto LAB30;

LAB31:    if (*((unsigned int *)t70) != 0)
        goto LAB32;

LAB33:    t77 = (t60 + 4);
    t78 = *((unsigned int *)t60);
    t79 = *((unsigned int *)t77);
    t80 = (t78 || t79);
    if (t80 > 0)
        goto LAB34;

LAB35:    t83 = *((unsigned int *)t60);
    t84 = (~(t83));
    t85 = *((unsigned int *)t77);
    t86 = (t84 || t85);
    if (t86 > 0)
        goto LAB36;

LAB37:    if (*((unsigned int *)t77) > 0)
        goto LAB38;

LAB39:    if (*((unsigned int *)t60) > 0)
        goto LAB40;

LAB41:    memcpy(t59, t87, 8);

LAB42:    goto LAB11;

LAB12:    xsi_vlog_unsigned_bit_combine(t3, 32, t25, 32, t59, 32);
    goto LAB16;

LAB14:    memcpy(t3, t25, 8);
    goto LAB16;

LAB17:    *((unsigned int *)t26) = 1;
    goto LAB20;

LAB19:    t43 = (t26 + 4);
    *((unsigned int *)t26) = 1;
    *((unsigned int *)t43) = 1;
    goto LAB20;

LAB21:    t48 = (t0 + 1208U);
    t49 = *((char **)t48);
    goto LAB22;

LAB23:    t48 = (t0 + 1368U);
    t54 = *((char **)t48);
    goto LAB24;

LAB25:    xsi_vlog_unsigned_bit_combine(t25, 32, t49, 32, t54, 32);
    goto LAB29;

LAB27:    memcpy(t25, t49, 8);
    goto LAB29;

LAB30:    *((unsigned int *)t60) = 1;
    goto LAB33;

LAB32:    t76 = (t60 + 4);
    *((unsigned int *)t60) = 1;
    *((unsigned int *)t76) = 1;
    goto LAB33;

LAB34:    t81 = (t0 + 1528U);
    t82 = *((char **)t81);
    goto LAB35;

LAB36:    t81 = (t0 + 1368U);
    t87 = *((char **)t81);
    goto LAB37;

LAB38:    xsi_vlog_unsigned_bit_combine(t59, 32, t82, 32, t87, 32);
    goto LAB42;

LAB40:    memcpy(t59, t82, 8);
    goto LAB42;

}


extern void work_m_00000000003735294327_0992325708_init()
{
	static char *pe[] = {(void *)Cont_8_0};
	xsi_register_didat("work_m_00000000003735294327_0992325708", "isim/tb_ARM_1_isim_beh.exe.sim/work/m_00000000003735294327_0992325708.didat");
	xsi_register_executes(pe);
}
