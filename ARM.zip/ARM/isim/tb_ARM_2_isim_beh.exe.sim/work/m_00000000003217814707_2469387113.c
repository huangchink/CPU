/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/ARM/tb_ARM_2.v";
static int ng1[] = {0, 0};
static int ng2[] = {1, 0};
static const char *ng3 = "arm_tb_program_2.txt";
static const char *ng4 = "arm_tb_mem_data_2.txt";
static const char *ng5 = "arm_tb_answer_2.txt";
static int ng6[] = {4, 0};
static unsigned int ng7[] = {1U, 0U};
static const char *ng8 = "error at mem[%2d] 0x%h != 0x%h ";
static unsigned int ng9[] = {0U, 0U};
static const char *ng10 = "Congratulation!! All data is correct";
static const char *ng11 = "You have %2d fault !!";



static void Always_49_0(char *t0)
{
    char t3[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;

LAB0:    t1 = (t0 + 3120U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(49, ng0);
    t2 = (t0 + 2928);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(49, ng0);
    t4 = (t0 + 1560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t3, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB8;

LAB6:    if (*((unsigned int *)t7) == 0)
        goto LAB5;

LAB7:    t13 = (t3 + 4);
    *((unsigned int *)t3) = 1;
    *((unsigned int *)t13) = 1;

LAB8:    t14 = (t3 + 4);
    t15 = (t6 + 4);
    t16 = *((unsigned int *)t6);
    t17 = (~(t16));
    *((unsigned int *)t3) = t17;
    *((unsigned int *)t14) = 0;
    if (*((unsigned int *)t15) != 0)
        goto LAB10;

LAB9:    t22 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t22 & 1U);
    t23 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t23 & 1U);
    t24 = (t0 + 1560);
    xsi_vlogvar_assign_value(t24, t3, 0, 0, 1);
    goto LAB2;

LAB5:    *((unsigned int *)t3) = 1;
    goto LAB8;

LAB10:    t18 = *((unsigned int *)t3);
    t19 = *((unsigned int *)t15);
    *((unsigned int *)t3) = (t18 | t19);
    t20 = *((unsigned int *)t14);
    t21 = *((unsigned int *)t15);
    *((unsigned int *)t14) = (t20 | t21);
    goto LAB9;

}

static void Initial_51_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;

LAB0:    t1 = (t0 + 3368U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(51, ng0);

LAB4:    xsi_set_current_line(53, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 1560);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(54, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 1720);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(55, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 1880);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);
    xsi_set_current_line(56, ng0);
    t2 = (t0 + 3176);
    xsi_process_wait(t2, 10000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(56, ng0);
    t3 = ((char*)((ng1)));
    t4 = (t0 + 1720);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 1);
    xsi_set_current_line(58, ng0);
    t2 = (t0 + 5564);
    t3 = *((char **)t2);
    xsi_vlogfile_readmemb(ng3, 0, ((char*)(t3)), 0, 0, 0, 0);
    xsi_set_current_line(59, ng0);
    t2 = (t0 + 5596);
    t3 = *((char **)t2);
    xsi_vlogfile_readmemh(ng4, 0, ((char*)(t3)), 0, 0, 0, 0);
    xsi_set_current_line(60, ng0);
    t2 = (t0 + 2200);
    xsi_vlogfile_readmemh(ng5, 0, t2, 0, 0, 0, 0);
    goto LAB1;

}

static void Always_64_2(char *t0)
{
    char t11[8];
    char t12[8];
    char t32[8];
    char t42[8];
    char t68[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    char *t43;
    char *t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    char *t57;
    char *t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    char *t64;
    char *t65;
    char *t66;
    char *t67;
    char *t69;

LAB0:    t1 = (t0 + 3616U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(64, ng0);
    t2 = (t0 + 3936);
    *((int *)t2) = 1;
    t3 = (t0 + 3648);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(65, ng0);

LAB5:    xsi_set_current_line(66, ng0);
    t4 = (t0 + 3424);
    xsi_process_wait(t4, 1000LL);
    *((char **)t1) = &&LAB6;
    goto LAB1;

LAB6:    xsi_set_current_line(66, ng0);
    t5 = (t0 + 5612);
    t6 = *((char **)t5);
    t7 = ((((char*)(t6))) + 56U);
    t8 = *((char **)t7);
    t9 = (t0 + 608);
    t10 = *((char **)t9);
    t9 = ((char*)((ng6)));
    memset(t11, 0, 8);
    xsi_vlog_unsigned_multiply(t11, 32, t10, 32, t9, 32);
    memset(t12, 0, 8);
    t13 = (t8 + 4);
    if (*((unsigned int *)t13) != 0)
        goto LAB8;

LAB7:    t14 = (t11 + 4);
    if (*((unsigned int *)t14) != 0)
        goto LAB8;

LAB11:    if (*((unsigned int *)t8) < *((unsigned int *)t11))
        goto LAB10;

LAB9:    *((unsigned int *)t12) = 1;

LAB10:    t16 = (t12 + 4);
    t17 = *((unsigned int *)t16);
    t18 = (~(t17));
    t19 = *((unsigned int *)t12);
    t20 = (t19 & t18);
    t21 = (t20 != 0);
    if (t21 > 0)
        goto LAB12;

LAB13:
LAB14:    goto LAB2;

LAB8:    t15 = (t12 + 4);
    *((unsigned int *)t12) = 1;
    *((unsigned int *)t15) = 1;
    goto LAB10;

LAB12:    xsi_set_current_line(67, ng0);

LAB15:    xsi_set_current_line(68, ng0);
    xsi_set_current_line(68, ng0);
    t22 = ((char*)((ng1)));
    t23 = (t0 + 2040);
    xsi_vlogvar_assign_value(t23, t22, 0, 0, 32);

LAB16:    t2 = (t0 + 2040);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 472);
    t6 = *((char **)t5);
    memset(t11, 0, 8);
    xsi_vlog_signed_less(t11, 32, t4, 32, t6, 32);
    t5 = (t11 + 4);
    t17 = *((unsigned int *)t5);
    t18 = (~(t17));
    t19 = *((unsigned int *)t11);
    t20 = (t19 & t18);
    t21 = (t20 != 0);
    if (t21 > 0)
        goto LAB17;

LAB18:    xsi_set_current_line(77, ng0);
    t2 = (t0 + 1880);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng9)));
    memset(t11, 0, 8);
    t6 = (t4 + 4);
    t7 = (t5 + 4);
    t17 = *((unsigned int *)t4);
    t18 = *((unsigned int *)t5);
    t19 = (t17 ^ t18);
    t20 = *((unsigned int *)t6);
    t21 = *((unsigned int *)t7);
    t45 = (t20 ^ t21);
    t46 = (t19 | t45);
    t47 = *((unsigned int *)t6);
    t48 = *((unsigned int *)t7);
    t49 = (t47 | t48);
    t50 = (~(t49));
    t51 = (t46 & t50);
    if (t51 != 0)
        goto LAB31;

LAB28:    if (t49 != 0)
        goto LAB30;

LAB29:    *((unsigned int *)t11) = 1;

LAB31:    t9 = (t11 + 4);
    t52 = *((unsigned int *)t9);
    t53 = (~(t52));
    t54 = *((unsigned int *)t11);
    t55 = (t54 & t53);
    t56 = (t55 != 0);
    if (t56 > 0)
        goto LAB32;

LAB33:    xsi_set_current_line(80, ng0);
    t2 = (t0 + 1880);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    xsi_vlogfile_write(1, 0, 0, ng11, 2, t0, (char)119, t4, 32);

LAB34:    xsi_set_current_line(82, ng0);
    xsi_vlog_finish(1);
    goto LAB14;

LAB17:    xsi_set_current_line(69, ng0);

LAB19:    xsi_set_current_line(70, ng0);
    t7 = (t0 + 5644);
    t8 = *((char **)t7);
    t9 = ((((char*)(t8))) + 56U);
    t10 = *((char **)t9);
    t13 = (t0 + 5676);
    t14 = *((char **)t13);
    t15 = ((((char*)(t14))) + 72U);
    t16 = *((char **)t15);
    t22 = (t0 + 5708);
    t23 = *((char **)t22);
    t24 = ((((char*)(t23))) + 64U);
    t25 = *((char **)t24);
    t26 = (t0 + 2040);
    t27 = (t26 + 56U);
    t28 = *((char **)t27);
    xsi_vlog_generic_get_array_select_value(t12, 32, t10, t16, t25, 2, 1, t28, 32, 1);
    t29 = (t0 + 2200);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    t33 = (t0 + 2200);
    t34 = (t33 + 72U);
    t35 = *((char **)t34);
    t36 = (t0 + 2200);
    t37 = (t36 + 64U);
    t38 = *((char **)t37);
    t39 = (t0 + 2040);
    t40 = (t39 + 56U);
    t41 = *((char **)t40);
    xsi_vlog_generic_get_array_select_value(t32, 32, t31, t35, t38, 2, 1, t41, 32, 1);
    memset(t42, 0, 8);
    t43 = (t12 + 4);
    t44 = (t32 + 4);
    t45 = *((unsigned int *)t12);
    t46 = *((unsigned int *)t32);
    t47 = (t45 ^ t46);
    t48 = *((unsigned int *)t43);
    t49 = *((unsigned int *)t44);
    t50 = (t48 ^ t49);
    t51 = (t47 | t50);
    t52 = *((unsigned int *)t43);
    t53 = *((unsigned int *)t44);
    t54 = (t52 | t53);
    t55 = (~(t54));
    t56 = (t51 & t55);
    if (t56 != 0)
        goto LAB21;

LAB20:    if (t54 != 0)
        goto LAB22;

LAB23:    t58 = (t42 + 4);
    t59 = *((unsigned int *)t58);
    t60 = (~(t59));
    t61 = *((unsigned int *)t42);
    t62 = (t61 & t60);
    t63 = (t62 != 0);
    if (t63 > 0)
        goto LAB24;

LAB25:
LAB26:    xsi_set_current_line(68, ng0);
    t2 = (t0 + 2040);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng2)));
    memset(t11, 0, 8);
    xsi_vlog_signed_add(t11, 32, t4, 32, t5, 32);
    t6 = (t0 + 2040);
    xsi_vlogvar_assign_value(t6, t11, 0, 0, 32);
    goto LAB16;

LAB21:    *((unsigned int *)t42) = 1;
    goto LAB23;

LAB22:    t57 = (t42 + 4);
    *((unsigned int *)t42) = 1;
    *((unsigned int *)t57) = 1;
    goto LAB23;

LAB24:    xsi_set_current_line(71, ng0);

LAB27:    xsi_set_current_line(72, ng0);
    t64 = (t0 + 1880);
    t65 = (t64 + 56U);
    t66 = *((char **)t65);
    t67 = ((char*)((ng7)));
    memset(t68, 0, 8);
    xsi_vlog_unsigned_add(t68, 32, t66, 32, t67, 32);
    t69 = (t0 + 1880);
    xsi_vlogvar_assign_value(t69, t68, 0, 0, 32);
    xsi_set_current_line(73, ng0);
    t2 = (t0 + 2040);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 5740);
    t6 = *((char **)t5);
    t7 = ((((char*)(t6))) + 56U);
    t8 = *((char **)t7);
    t9 = (t0 + 5772);
    t10 = *((char **)t9);
    t13 = ((((char*)(t10))) + 72U);
    t14 = *((char **)t13);
    t15 = (t0 + 5804);
    t16 = *((char **)t15);
    t22 = ((((char*)(t16))) + 64U);
    t23 = *((char **)t22);
    t24 = (t0 + 2040);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    xsi_vlog_generic_get_array_select_value(t11, 32, t8, t14, t23, 2, 1, t26, 32, 1);
    t27 = (t0 + 2200);
    t28 = (t27 + 56U);
    t29 = *((char **)t28);
    t30 = (t0 + 2200);
    t31 = (t30 + 72U);
    t33 = *((char **)t31);
    t34 = (t0 + 2200);
    t35 = (t34 + 64U);
    t36 = *((char **)t35);
    t37 = (t0 + 2040);
    t38 = (t37 + 56U);
    t39 = *((char **)t38);
    xsi_vlog_generic_get_array_select_value(t12, 32, t29, t33, t36, 2, 1, t39, 32, 1);
    xsi_vlogfile_write(1, 0, 0, ng8, 4, t0, (char)119, t4, 32, (char)118, t11, 32, (char)118, t12, 32);
    goto LAB26;

LAB30:    t8 = (t11 + 4);
    *((unsigned int *)t11) = 1;
    *((unsigned int *)t8) = 1;
    goto LAB31;

LAB32:    xsi_set_current_line(78, ng0);
    xsi_vlogfile_write(1, 0, 0, ng10, 1, t0);
    goto LAB34;

}


extern void work_m_00000000003217814707_2469387113_init()
{
	static char *pe[] = {(void *)Always_49_0,(void *)Initial_51_1,(void *)Always_64_2};
	xsi_register_didat("work_m_00000000003217814707_2469387113", "isim/tb_ARM_2_isim_beh.exe.sim/work/m_00000000003217814707_2469387113.didat");
	xsi_register_executes(pe);
}
